# Postage

## [v1.5.3](https://github.com/DrKlampz/Postage/tree/v1.5.3) (2026-11-14)
[Full Changelog](https://github.com/DrKlampz/Postage/compare/v1.5.2...v1.5.3) [Previous Releases](https://github.com/DrKlampz/Postage/releases)

- Postage v1.5.3: one Leather quick-attach button  
    Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>  
    Claude-Session: https://claude.ai/code/session\_016tjqgsa2XbatSMrUya2RRK  
