# Postage

## [v1.5.5](https://github.com/DrKlampz/Postage/tree/v1.5.5) (2026-11-14)
[Full Changelog](https://github.com/DrKlampz/Postage/compare/v1.5.4...v1.5.5) [Previous Releases](https://github.com/DrKlampz/Postage/releases)

- Release v1.5.5  
    Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>  
    Claude-Session: https://claude.ai/code/session\_016tjqgsa2XbatSMrUya2RRK  
- Postage: lift the inbox paging row when it overhangs the window  
    Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>  
    Claude-Session: https://claude.ai/code/session\_016tjqgsa2XbatSMrUya2RRK  
